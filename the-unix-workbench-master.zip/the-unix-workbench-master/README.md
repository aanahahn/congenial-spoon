# [The Unix Workbench](http://seankross.com/the-unix-workbench/)

[![Build Status](https://travis-ci.org/seankross/the-unix-workbench.svg?branch=master)](https://travis-ci.org/seankross/the-unix-workbench)

An introduction to Unix for everyone.

[![CC0](https://licensebuttons.net/p/zero/1.0/88x31.png)](https://creativecommons.org/publicdomain/zero/1.0/)

This work by [Sean Kross](http://seankross.com) is licensed 
[CC0](https://creativecommons.org/publicdomain/zero/1.0/). Zero rights reserved.